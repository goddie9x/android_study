package com.god.study;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Vector;

public class MainActivity extends AppCompatActivity {
    private final int REQUEST_LOGOUT_CODE = 1;
    private final String STATE = MainActivity.class.getSimpleName();
    private TextView expressLabel;
    private TextView outputLabel;
    private boolean isHaveToClearInput = false;
    private Vector<CalState> history = new Vector<CalState>();
    private CalState currentCalState = new CalState();
    private String crrOperator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        expressLabel = (TextView) findViewById(R.id.cal_express_label);
        outputLabel = (TextView) findViewById(R.id.output_label);

        if (savedInstanceState != null) {
            savedInstanceState.getBoolean("isHaveToClearInput");
            savedInstanceState.getString("crrOperator");
            CalState[] prevHistory = (CalState[]) savedInstanceState.getParcelableArray("history");
            for (CalState item : prevHistory) {
                history.add(item);
            }
            CalState backUpstate = savedInstanceState.getParcelable("currentCalState");
            setExpress(backUpstate.express);
            setValue(backUpstate.value);
        }
        Button historyBtn = (Button) findViewById(R.id.history);
        initHistoryFragment();
        historyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HistoryDialogFragment
                        .showHistoryDialogFragment(getSupportFragmentManager(),
                                history.toArray(new CalState[history.size()]));
            }
        });
        initEvent();
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        Log.e(STATE, "onRestoreInstanceState");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("isHaveToClearInput", isHaveToClearInput);
        outState.putString("crrOperator", crrOperator);
        outState.putParcelableArray("history", history.toArray(new CalState[history.size()]));
        outState.putParcelable("currentCalState", currentCalState);
    }

    private void initHistoryFragment() {
        HistoryDialogFragment.setOnCompleteListener(result -> {
            if (result != null) {
                if (result.isClearHistory) {
                    history.clear();
                }
                if (result.selectedIndex > -1 && result.selectedIndex < history.size()) {
                    CalState selectedCalState = history.elementAt(result.selectedIndex);
                    setExpress(selectedCalState.express);
                    setValue(selectedCalState.value);
                }
            }
        });
    }

    private void initEvent() {
        initEventForClearAllBtn();
        initEventForClearResultBtn();
        initEventForClearSingleBtn();
        initEventForEqualBtn();
        initEventForReverseBtn();
        initEventForOpositeBtn();
        initEventForSqrtBtn();
        initEventForNumbersBtn();
        initEventForTwoHandOperatorsBtn();
        initEventForDotBtn();

    }

    private void initEventForNumbersBtn() {
        handleNumberEventClick((Button) findViewById(R.id.zero));
        handleNumberEventClick((Button) findViewById(R.id.one));
        handleNumberEventClick((Button) findViewById(R.id.two));
        handleNumberEventClick((Button) findViewById(R.id.three));
        handleNumberEventClick((Button) findViewById(R.id.four));
        handleNumberEventClick((Button) findViewById(R.id.five));
        handleNumberEventClick((Button) findViewById(R.id.six));
        handleNumberEventClick((Button) findViewById(R.id.seven));
        handleNumberEventClick((Button) findViewById(R.id.eight));
        handleNumberEventClick((Button) findViewById(R.id.nine));
    }

    private void initEventForDotBtn() {
        ((Button) findViewById(R.id.dot)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String crrInputString = getInputText();
                if (!crrInputString.contains(".")) {
                    outputLabel.setText(crrInputString + ".");
                }
            }
        });
    }

    private String nomarlizeStringTypeDoubleToString(String stringVal) {
        int lastIndex = stringVal.length() - 1;
        if(lastIndex<1){
            return stringVal;
        }
        double val = Double.parseDouble(stringVal);
        String lastTwoChar = stringVal.substring(lastIndex - 1, lastIndex);
        if (
                (lastTwoChar == ".0")
                        || (val >= Integer.MIN_VALUE
                        && val <= Integer.MAX_VALUE
                        && val == (int) val)
        ) {
            return (int) val + "";
        } else {
            return stringVal;
        }
    }

    private String nomarlizeDoubleToString(double val) {
        if(val >= Integer.MIN_VALUE && val <= Integer.MAX_VALUE && val == (int) val){
            return ""+(int)val;
        }
        else{
            return ""+val;
        }
    }

    private void initEventForClearAllBtn() {
        ((Button) findViewById(R.id.clear_all)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                crrOperator = null;
                setNewCalState("", 0);
            }
        });
    }

    private void initEventForClearResultBtn() {
        ((Button) findViewById(R.id.clear_cal)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setValue(0);
            }
        });
    }

    private void initEventForClearSingleBtn() {
        ((Button) findViewById(R.id.clear_single)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strNum = getInputText();
                double newValue = Double.parseDouble(strNum);

                if(strNum.contains("E")){
                    newValue/=10;
                }
                else{
                    int lastIndex = strNum.length() - 1;
                    if(lastIndex!=0){
                        strNum = strNum.substring(0, (strNum.charAt(lastIndex) == '.' ? lastIndex - 1 : lastIndex));
                        newValue = Double.parseDouble(strNum);
                    }else{
                        newValue = 0;
                    }
                }
                setValue(newValue);
            }
        });
    }
    private void initEventForTwoHandOperatorsBtn() {
        handleOperatorEventClick((Button) findViewById(R.id.div));
        handleOperatorEventClick((Button) findViewById(R.id.minus));
        handleOperatorEventClick((Button) findViewById(R.id.plus));
        handleOperatorEventClick((Button) findViewById(R.id.multiple));
        handleOperatorEventClick((Button) findViewById(R.id.mod));
        handleOperatorEventClick((Button) findViewById(R.id.exponentiation));
    }

    private void initEventForReverseBtn() {
        ((Button) findViewById(R.id.reverse)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleReverseValue();
            }
        });
    }

    private void initEventForOpositeBtn() {
        ((Button) findViewById(R.id.opposite)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleOppositeValue();
            }
        });
    }

    private void initEventForSqrtBtn() {
        ((Button) findViewById(R.id.sqrt)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSqrtValue();
            }
        });
    }

    private void initEventForEqualBtn() {
        ((Button) findViewById(R.id.equal)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startCal();
            }
        });
    }

    private void startCal() {
        if (crrOperator == null) {
            return;
        }
        String crrInputString = getInputText();
        int lastIndex = crrInputString.length() - 1;
        if (crrInputString.charAt(lastIndex) == '.') {
            crrInputString.substring(0, lastIndex);
        }
        double crrInputNumber = 0;
        try {
            crrInputNumber = Double.parseDouble(crrInputString);
        } catch (NumberFormatException e) {
            return;
        }
        switch (crrOperator) {
            case "+": {
                handleAddValue(crrInputNumber);
                break;
            }
            case "-": {
                handleMinuesValue(crrInputNumber);
                break;
            }
            case "/": {
                handleDivValue(crrInputNumber);
                break;
            }
            case "x": {
                handleMultipleValue(crrInputNumber);
                break;
            }
            case "%": {
                handleModuleValue(crrInputNumber);
                break;
            }
            case "^": {
                handleExponentiationValue(crrInputNumber);
                break;
            }
        }
        crrOperator = null;
    }

    private void handleNumberEventClick(Button button) {
        button.setOnClickListener(v -> {
            String selectedNumberString = button.getText().toString();
            String valueString = getInputText();
            if (isHaveToClearInput || valueString == "0") {
                isHaveToClearInput = false;
                outputLabel.setText(selectedNumberString);
            } else {
                outputLabel.setText(valueString+selectedNumberString);
            }
        });
    }

    private void handleOperatorEventClick(Button button) {
        button.setOnClickListener(v -> {
            if (crrOperator != null) {
                startCal();
            }
            String crrValString = getInputText();
            double crrVal = 0;
            try {
                crrVal = Double.parseDouble(crrValString);
            } catch (NumberFormatException e) {
                return;
            }
            String selectedOperator = button.getText().toString();
            String newExpress = crrValString + selectedOperator;
            setValue(crrVal);
            setExpress(newExpress);
            crrOperator = selectedOperator;
            isHaveToClearInput = true;
        });
    }

    private void handleDivValue(double crrInputNumber) {
        if (crrInputNumber == 0) {
            if (currentCalState.value == 0) {
                outputLabel.setText("Result is undefined");
            } else {
                outputLabel.setText("Cannot divide by zero");
            }
        } else {
            String express = nomarlizeDoubleToString(currentCalState.value) + "/"
                    + nomarlizeDoubleToString(crrInputNumber) + "=";

            setNewCalState(
                    express
                    ,
                    currentCalState.value / crrInputNumber
            );
        }
    }

    private void handleAddValue(double crrInputNumber) {
        setNewCalState(
                nomarlizeDoubleToString(currentCalState.value) + "+"
                        + nomarlizeDoubleToString(crrInputNumber) + "=",
                currentCalState.value + crrInputNumber
        );
    }

    private void handleMultipleValue(double crrInputNumber) {
        setNewCalState(
                nomarlizeDoubleToString(currentCalState.value) + "x"
                        + nomarlizeDoubleToString(crrInputNumber) + "=",
                currentCalState.value * crrInputNumber
        );
    }

    private void handleModuleValue(double crrInputNumber) {
        setNewCalState(
                currentCalState.value + "%"
                        + nomarlizeDoubleToString(crrInputNumber) + "=",
                currentCalState.value % crrInputNumber
        );
    }

    private void handleExponentiationValue(double crrInputNumber) {
        try {
            double newVal = Math.pow(currentCalState.value, crrInputNumber);
            setNewCalState(
                    currentCalState.value + "^" +
                            nomarlizeDoubleToString(crrInputNumber) + "=",
                    newVal
            );
        } catch (ArithmeticException e) {
            outputLabel.setText("Invalid input");
        }
    }

    private void handleMinuesValue(double crrInputNumber) {
        setNewCalState(
                currentCalState.value + "-"
                        + nomarlizeDoubleToString(crrInputNumber) + "=",
                currentCalState.value - crrInputNumber
        );
    }

    private void handleOppositeValue() {
        String lastResultString = getInputText();
        double lastResult = Double.parseDouble(lastResultString);
        setNewCalState(
                "-(" + lastResult + ")",
                -lastResult
        );
    }

    private void handleSqrtValue() {
        String lastResultString = getInputText();
        double lastResult = Double.parseDouble(lastResultString);
        if (lastResult < 0) {
            outputLabel.setText("Invalid input");
        } else {
            setNewCalState(
                    "v(" + lastResult + ")",
                    Math.sqrt(lastResult)
            );
        }
    }

    private void handleReverseValue() {
        String lastResultString = getInputText();
        double lastResult = Double.parseDouble(lastResultString);
        setNewCalState(
                "1/(" + lastResultString + ")",
                1 / lastResult
        );
    }
    private String getInputText(){
        return nomarlizeStringTypeDoubleToString(outputLabel.getText().toString());
    }
    private void setNewCalState(String express, double value) {
        if (!currentCalState.isDefault()) {
            history.add(currentCalState.clone());
        }
        currentCalState.express = express;
        currentCalState.value = value;
        expressLabel.setText(express);
        outputLabel.setText(nomarlizeDoubleToString(value));
    }

    private void setValue(double value) {
        currentCalState.value = value;
        outputLabel.setText(nomarlizeDoubleToString(value));
    }

    private void setExpress(String express) {
        currentCalState.express = express;
        expressLabel.setText(express);
    }
}