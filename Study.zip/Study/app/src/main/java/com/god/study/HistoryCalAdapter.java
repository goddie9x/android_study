package com.god.study;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Vector;

public class HistoryCalAdapter extends RecyclerView.Adapter  {
    private CalState[] history;
    private HistoryDialogFragment activity;

    public  interface OnItemClickListener{
        public void onItemClick(HistoryCalAdapter parent, View view, int position);
    }
    private  OnItemClickListener onItemClickListener;
    public void setOnItemClickListener(OnItemClickListener mListener){
        this.onItemClickListener = mListener;
    }
    public HistoryCalAdapter(HistoryDialogFragment activity, CalState[] history) {
        this.activity = activity;
        this.history = history;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.caculate_history_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(itemView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        CalState crrCalState = history[position];
        ((ViewHolder)holder).expressLabel.setText(crrCalState.express);
        ((ViewHolder)holder).valueLabel.setText(crrCalState.value+"");
        onItemClickListener.onItemClick(this,((ViewHolder) holder).view,position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return history.length;
    }

    public void clear() {
        history = new CalState[0];
        notifyDataSetChanged();
    }
    public class ViewHolder extends RecyclerView.ViewHolder{
        private View view;
        private TextView expressLabel;
        private TextView valueLabel;
        public ViewHolder(View itemView){
            super(itemView);
            expressLabel = (TextView) itemView.findViewById(R.id.cal_express_label);
            valueLabel = (TextView) itemView.findViewById(R.id.output_label);
        }
    }
}
