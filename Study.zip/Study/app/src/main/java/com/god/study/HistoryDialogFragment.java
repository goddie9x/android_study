package com.god.study;

import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

public class HistoryDialogFragment extends DialogFragment {
    private CalState[] history;
    private RecyclerView recyclerView;
    private HistoryCalDialogResult historyCalDialogResult = new HistoryCalDialogResult();
    private Button clearHistoryBtn;
    private HistoryCalAdapter adapter;

    public interface OnCompleteListener {
        void onDialogComplete(HistoryCalDialogResult result);
    }
    private static OnCompleteListener mListener;
    public static void setOnCompleteListener(OnCompleteListener listener) {
        mListener = listener;
    }
    private  static  HistoryDialogFragment historyDialogFragment;
    public  static void showHistoryDialogFragment(FragmentManager fragmentManager, CalState[] history){
        if(historyDialogFragment==null){
            historyDialogFragment = new HistoryDialogFragment();
        }
        historyDialogFragment.history = history;
        historyDialogFragment.show(fragmentManager,"show");
    }
    @Nullable
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        Dialog dialog = new Dialog(requireContext());
        dialog.setContentView(R.layout.dlg_fragment_history);
        recyclerView = (RecyclerView) dialog.findViewById(R.id.history);
        clearHistoryBtn = (Button) dialog.findViewById(R.id.clear_history);
        clearHistoryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                historyCalDialogResult.isClearHistory=true;
                if(adapter!=null){
                    adapter.clear();
                }
                mListener.onDialogComplete(historyCalDialogResult);
            }
        });

        return dialog;
    }
    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if(history!=null){
            adapter = new HistoryCalAdapter(this, history);
            adapter.setOnItemClickListener(new HistoryCalAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(HistoryCalAdapter parent, View view, int position) {
                    historyCalDialogResult.selectedIndex = position;
                    mListener.onDialogComplete(historyCalDialogResult);
                    dialog.dismiss();
                }
            });
            recyclerView.setAdapter(adapter);
        }
        if (dialog != null) {
            // Set the width of the dialog to 80% of the screen width
            int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.8);
            dialog.getWindow().setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }
}